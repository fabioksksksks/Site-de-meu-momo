const texto = `
Oi minha vida 💗

Esse site é só uma das muitas formas que encontrei pra te lembrar do quanto você é especial pra mim.

Você é minha tulipa, meu amo, meu pedacinho de céu.
Obrigada por existir e fazer meu mundo mais bonito.

Te amo pra sempre. 🌷
`;

let i = 0;
const carta = document.getElementById("carta");

function digitar() {
  if (i < texto.length) {
    carta.innerHTML += texto.charAt(i);
    i++;
    setTimeout(digitar, 60);
  }
}
digitar();

function verificarCoraçao(botao) {
  if (botao.innerHTML === "💘") {
    document.getElementById("mensagem-jogo").textContent = "Acertou, meu coração é todinho seu! 💞";
  } else {
    document.getElementById("mensagem-jogo").textContent = "Hmm... tenta de novo! 😘";
  }
}
